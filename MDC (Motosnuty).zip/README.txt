Thanks to AmitabhTechz for giving me this, as well as a lot of other roms.
- SM64 Beta Hack Archive